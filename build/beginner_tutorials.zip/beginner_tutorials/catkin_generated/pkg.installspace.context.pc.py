# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/mh/catkin_ws/install/include".split(';') if "/home/mh/catkin_ws/install/include" != "" else []
PROJECT_CATKIN_DEPENDS = "message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "beginner_tutorials"
PROJECT_SPACE_DIR = "/home/mh/catkin_ws/install"
PROJECT_VERSION = "0.0.0"
