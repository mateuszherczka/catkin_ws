# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/mh/catkin_ws/src/beginner_tutorials/msg/Num.msg"
services_str = "/home/mh/catkin_ws/src/beginner_tutorials/srv/AddTwoInts.srv"
pkg_name = "beginner_tutorials"
dependencies_str = "std_msgs"
langs = "gencpp;genlisp;genpy"
dep_include_paths_str = "beginner_tutorials;/home/mh/catkin_ws/src/beginner_tutorials/msg;std_msgs;/opt/ros/indigo/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/indigo/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
